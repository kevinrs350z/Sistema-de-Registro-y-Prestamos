import { Component, OnInit } from '@angular/core';
import { REPORTES_CONFIG } from './reportes.config';
import { DashboardReportesService } from '../../../../services/reportes/dashboard-reportes.service';
import { ExportService } from '../../../../services/export.service';

@Component({
  selector: 'app-report-viewer',
  templateUrl: './report-viewer.component.html',
  styleUrls: ['./report-viewer.component.css'],
  standalone: true,
  imports: []
})
export class ReportViewerComponent implements OnInit {

  menu = Object.keys(REPORTES_CONFIG);   // dashboard, equipos, alumnos...
  reporteActual = 'dashboard';

  config: any = {};
  datos: any = {};

  mensaje: string | null = null;
  cargando = false;

  constructor(
    private dashboardSrv: DashboardReportesService,
    private exportSrv: ExportService
  ) {}

  ngOnInit() {
    this.cargarReporte(this.reporteActual);
  }

  seleccionarReporte(tipo: string) {
    this.reporteActual = tipo;
    this.cargarReporte(tipo);
  }

  cargarReporte(tipo: string) {
    this.config = REPORTES_CONFIG[tipo];
    this.datos = {};
    this.cargando = true;

    const peticiones = this.config.endpoints.map((ep: any) => {
      return this.dashboardSrv[ep.metodo]().toPromise().then(res => {
        this.datos[ep.key] = res;
      });
    });

    Promise.all(peticiones)
      .then(() => this.cargando = false)
      .catch(() => {
        this.mostrarMensaje('Error al cargar el reporte.');
        this.cargando = false;
      });
  }

  mostrarMensaje(msg: string) {
    this.mensaje = msg;
    setTimeout(() => this.mensaje = null, 3000);
  }

  exportarPDF() {
    this.exportSrv.exportarPDF('contenidoPDF', `${this.config.title}.pdf`)
      .catch(() => this.mostrarMensaje('Error al exportar PDF.'));
  }

  exportarExcel() {
    const sheets = this.config.excel(this.datos);
    try {
      this.exportSrv.exportarExcel(sheets, `${this.config.title}.xlsx`);
    } catch {
      this.mostrarMensaje('Error al exportar Excel.');
    }
  }
}
